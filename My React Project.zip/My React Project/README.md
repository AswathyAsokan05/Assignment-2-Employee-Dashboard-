# Employee Dashboard (React + Vite)

Simple React app implementing an Employee Dashboard that fetches user data from an external API and an Employee Form.

Features:
- Navbar with Home and Employee Form links
- Dashboard (Home) that fetches users from https://jsonplaceholder.typicode.com/users and displays ID, Name, Email
 - Dashboard (Home) that fetches users from https://jsonplaceholder.typicode.com/users and displays ID, Name, Email (as requested)
- Employee Form with fields: Name, Designation, Location, Salary (no POST to API as requested)
- Routing with react-router-dom
- Styling via Bootstrap CDN

Quick start (Windows PowerShell):

1. Install dependencies

```powershell
cd "c:\Users\ARYA ASHOKAN\My React Project"
npm install
```

2. Run dev server

```powershell
npm run dev
```

Open the dev server URL (usually http://localhost:5173) in a browser.

Notes:
- No frontend POST is performed; the Employee Form logs the values to the console and shows a success message.
- If you prefer Create React App instead of Vite, I can adapt the scaffold.
 - The dashboard now includes a search box and a toggle between table and card views. The table shows ID, Name, Email, Company, and City. Avatars and improved styling were added.
 - The dashboard now includes a search box and a toggle between table and card views. The default view is the Card/Grid view and cards show ID, Name, Email, Company, and City. Avatars and improved styling were added.
