import React, { useEffect, useState, useMemo } from 'react'

function Avatar({ name }) {
  const initials = name ? name.split(' ').map(n => n[0]).slice(0,2).join('').toUpperCase() : 'EE'
  return <div className="avatar">{initials}</div>
}

export default function Dashboard() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [query, setQuery] = useState('')
  const [view, setView] = useState('table') // 'table' or 'cards'

  useEffect(() => {
    setLoading(true)
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(res => {
        if (!res.ok) throw new Error('Network response was not ok')
        return res.json()
      })
      .then(data => setUsers(data))
      .catch(err => setError(err.message))
      .finally(() => setLoading(false))
  }, [])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return users
    return users.filter(u =>
      String(u.id).includes(q) ||
      (u.name || '').toLowerCase().includes(q) ||
      (u.email || '').toLowerCase().includes(q) ||
      (u.username || '').toLowerCase().includes(q) ||
      (u.phone || '').toLowerCase().includes(q)
    )
  }, [users, query])

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h2 className="mb-0">Employee Dashboard</h2>
          <small className="text-muted">A fresh, responsive view of employees</small>
        </div>

        <div className="d-flex gap-2 align-items-center">
          <div className="input-group">
            <span className="input-group-text bg-white"><i className="bi bi-search"></i></span>
            <input className="form-control" placeholder="Search by id, username, name or phone" value={query} onChange={e => setQuery(e.target.value)} />
          </div>
          <div className="btn-group" role="group" aria-label="View toggle">
            <button type="button" className={"btn btn-sm " + (view === 'table' ? 'btn-primary' : 'btn-outline-primary')} onClick={() => setView('table')} title="Table view"><i className="bi bi-table"></i></button>
            <button type="button" className={"btn btn-sm " + (view === 'cards' ? 'btn-primary' : 'btn-outline-primary')} onClick={() => setView('cards')} title="Card view"><i className="bi bi-grid-3x3-gap-fill"></i></button>
          </div>
        </div>
      </div>

      {loading && <div className="alert alert-info">Loading...</div>}
      {error && <div className="alert alert-danger">Error: {error}</div>}

      {!loading && !error && (
        <>
          <div className="mb-3">
            <span className="badge bg-secondary">Total: {users.length}</span>
            {query && <span className="ms-2">Showing: {filtered.length}</span>}
          </div>

          {view === 'table' ? (
            <div className="table-responsive shadow-sm rounded">
              <table className="table table-hover align-middle mb-0 bg-white">
                <thead className="table-light">
                  <tr>
                    <th style={{width: '80px'}}>ID</th>
                    <th style={{width: '60px'}}></th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Company</th>
                    <th>City</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(u => (
                    <tr key={u.id}>
                      <td className="fw-bold">{u.id}</td>
                      <td><Avatar name={u.name} /></td>
                      <td>{u.name}</td>
                      <td>{u.email}</td>
                      <td>{u.company?.name}</td>
                      <td>{u.address?.city}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="row g-3">
              {filtered.map(u => (
                <div key={u.id} className="col-12 col-sm-6 col-md-4">
                  <div className="card h-100 shadow-sm employee-card">
                    <div className="card-body d-flex gap-3 align-items-center">
                      <Avatar name={u.name} />
                      <div>
                        <h6 className="card-title mb-1">{u.name} <small className="text-muted">#{u.id}</small></h6>
                        <p className="mb-1"><i className="bi bi-envelope me-2"></i>{u.email}</p>
                        <p className="mb-0 text-muted small">{u.company?.name} — {u.address?.city}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  )
}
