import React, { useState } from 'react'

export default function EmployeeForm() {
  const [form, setForm] = useState({ name: '', designation: '', location: '', salary: '' })
  const [submitted, setSubmitted] = useState(false)

  function handleChange(e) {
    const { name, value } = e.target
    setForm(prev => ({ ...prev, [name]: value }))
  }

  function handleSubmit(e) {
    e.preventDefault()
    // Requirement: No need to post data from frontend. We'll just mark submitted and log the values.
    console.log('Employee form values:', form)
    setSubmitted(true)
  }

  return (
    <div>
      <h2>Employee Form</h2>
      <form onSubmit={handleSubmit} className="card p-3">
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input name="name" className="form-control" value={form.name} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label className="form-label">Designation</label>
          <input name="designation" className="form-control" value={form.designation} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label className="form-label">Location</label>
          <input name="location" className="form-control" value={form.location} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label className="form-label">Salary</label>
          <input name="salary" type="number" className="form-control" value={form.salary} onChange={handleChange} required />
        </div>

        <button className="btn btn-primary" type="submit">Submit</button>

        {submitted && (
          <div className="alert alert-success mt-3">Form data captured locally (see console). No network post performed.</div>
        )}
      </form>
    </div>
  )
}
